package com.cg.springmvc.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.springmvc.dto.Customer;
import com.cg.springmvc.dto.Transactions;

@Repository("paymentwalletdao")
public class PaymentWalletDaoImpl implements IPaymentWalletDao
{
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		Transactions t1 = new Transactions();
		entitymanager.persist(customer);
		t1.setCustMobileNo(customer.getCustMobileNo());
		t1.setTransamount(0);
		t1.setCre_deb("credit");
		t1.setBalance(customer.getInitialBalance());
		Date date = new Date();
		t1.setDate(String.valueOf(dateFormat.format(date)));
		
		entitymanager.persist(t1);
		entitymanager.flush();
		System.out.println("createAccountDaoImpl()");
	}

	@Override
	public void deposit(String custMobileNo, double amount) {
		// TODO Auto-generated method stub
		System.out.println("depositDaoImpl()");
		Transactions t4 = new Transactions();
		Customer customer = entitymanager.find(Customer.class, custMobileNo);
		double iniBal=customer.getInitialBalance();
		iniBal+=amount;
		customer.setInitialBalance(iniBal);
		t4.setCustMobileNo(custMobileNo);
		t4.setBalance(iniBal);
		t4.setTransamount(amount);
		t4.setCre_deb("Credit");
		Date date = new Date();
		t4.setDate(String.valueOf(dateFormat.format(date)));
		entitymanager.persist(t4);
		entitymanager.flush();
		
	}

	@Override
	public void withdraw(String custMobileNo, double amount) {
		// TODO Auto-generated method stub
		Transactions t5 = new Transactions();
		Customer customer = entitymanager.find(Customer.class, custMobileNo);
		double iniBal=customer.getInitialBalance();
		iniBal-=amount;
		System.out.println(iniBal);
		customer.setInitialBalance(iniBal);
		t5.setCustMobileNo(custMobileNo);
		t5.setCre_deb("Debit");
		t5.setBalance(iniBal);
		t5.setTransamount(amount);
		Date date = new Date();
		t5.setDate(String.valueOf(dateFormat.format(date)));
		entitymanager.persist(t5);
		entitymanager.flush();
		
	}

	@Override
	public double checkBalance(String custMobileNo) {
		// TODO Auto-generated method stub
		Customer cust = entitymanager.find(Customer.class, custMobileNo);
		double amt =cust.getInitialBalance();
		System.out.println(amt);
		return amt;
		
		
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		// TODO Auto-generated method stub
		Transactions t3 = new Transactions();
		Transactions t4 = new Transactions();
		Customer cust1 = entitymanager.find(Customer.class, sender);
		double amt1 =cust1.getInitialBalance();
		Customer cust2 = entitymanager.find(Customer.class, reciever);
		double amt2 =cust2.getInitialBalance();
		amt1=amt1-amount;
		amt2=amt2+amount;
		cust1.setInitialBalance(amt1);
		cust2.setInitialBalance(amt2);
		t3.setCustMobileNo(sender);
		t3.setBalance(amt1);
		t3.setCre_deb("Debit");
		t3.setTransamount(amount);
		Date date = new Date();
		t3.setDate(String.valueOf(dateFormat.format(date)));
		entitymanager.persist(t3);
		t4.setCustMobileNo(reciever);
		t4.setCre_deb("Credit");
		t4.setBalance(amt2);
		t4.setTransamount(amount);
		Date date2 = new Date();
		t4.setDate(String.valueOf(dateFormat.format(date2)));
		entitymanager.persist(t4);
		entitymanager.flush();
	}

	@Override
	public boolean accountExist(String custMobileNo) {
		// TODO Auto-generated method stub
		
		Customer cust = entitymanager.find(Customer.class,custMobileNo);
		if(cust==null)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}

	@Override
	public List<Transactions> getTransList(String mobileNo) {
		// TODO Auto-generated method stub
		String qr = "select trans from Transactions trans where mobileNo ="+mobileNo;
		TypedQuery<Transactions> query = entitymanager.createQuery(qr, Transactions.class);
		List<Transactions> list = query.getResultList();
		return list;
	}

}
