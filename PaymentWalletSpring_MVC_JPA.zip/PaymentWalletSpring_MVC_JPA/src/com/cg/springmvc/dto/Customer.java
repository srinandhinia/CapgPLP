package com.cg.springmvc.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="paymentwallet")
public class Customer 
{
	@Column(name="cust_name")

	@Size(min = 3, max = 20, message = 
			   "Username must be between 3 and 20   characters long.")
    @Pattern(regexp = "^[A-Z]{1}[a-z]{1,10}", message = 
                      "Name invalid! Name should start with capital letter and should be of minimum 2 characters")
	@NotEmpty(message="Name should not be empty")
	private String custName;
	
	@Id
	@Column(name="cust_mobno")
	@Size(min = 10, max = 10, message = 
			   "Mobile number must be 10 characters long")
	@Pattern(regexp = "^[6789][0-9]{9}", message = 
             "Mobile Number Invalid! Please enter valid Indian mobile number of 10 digits e.g 9867988985")
	@NotEmpty(message="Mobile number should not be empty")
	private String custMobileNo;
	
	@Column(name="cust_age")
	private float custAge;
	
	@Column(name="ini_bal")
	private double initialBalance;

	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustMobileNo() {
		return custMobileNo;
	}
	public void setCustMobileNo(String custMobileNo) {
		this.custMobileNo = custMobileNo;
	}
	public float getCustAge() {
		return custAge;
	}
	public void setCustAge(float custAge) {
		this.custAge = custAge;
	}
	public double getInitialBalance() {
		return initialBalance;
	}
	public void setInitialBalance(double initialBalance) {
		this.initialBalance = initialBalance;
	}
	
	public Customer(String custName, String custMobileNo, float custAge,
			double initialBalance) {
		super();
		this.custName = custName;
		this.custMobileNo = custMobileNo;
		this.custAge = custAge;
		this.initialBalance = initialBalance;
	}
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	


}
