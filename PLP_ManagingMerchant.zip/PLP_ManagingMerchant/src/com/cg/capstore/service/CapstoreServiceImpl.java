package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.dao.CapstoreDAO;
import com.cg.capstore.dto.Merchant;
import com.cg.capstore.dto.Product;

@Service
@Transactional
public class CapstoreServiceImpl implements CapstoreService {

	@Autowired
	private CapstoreDAO capstoredao;
	
	@Override
	public void save(Merchant merchant) {
		// TODO Auto-generated method stub
		capstoredao.save(merchant);
	}

	@Override
	public void delete(String merchantUId) {
		
		capstoredao.delete(merchantUId);
	}

	@Override
	public List<Merchant> loadAll() {
		
		return capstoredao.loadAll();
	}

	@Override
	public List<Merchant> getAllThirdPartyMerchants() {
		// TODO Auto-generated method stub
		return capstoredao.getAllThirdPartyMerchants();
	}

	@Override
	public List<Merchant> getThirdPartyMerId() {
		// TODO Auto-generated method stub
		return capstoredao.getThirdPartyMerId();
	}

	@Override
	public List<Product> allProductsOfThirdParty(String merId) {
		// TODO Auto-generated method stub
		return capstoredao.allProductsOfThirdParty(merId);
	}

}
