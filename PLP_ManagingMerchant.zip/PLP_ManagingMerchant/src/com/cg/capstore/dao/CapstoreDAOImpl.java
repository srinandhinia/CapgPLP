package com.cg.capstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;



import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.dto.Merchant;
import com.cg.capstore.dto.Product;



@Repository
@Transactional
public class CapstoreDAOImpl implements CapstoreDAO {

	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public void save(Merchant merchant) {

		entitymanager.persist(merchant);
		entitymanager.flush();
	}

	@Override
	public void delete(String merchantUId) {
		Merchant merch = entitymanager.find(Merchant.class, merchantUId);
		entitymanager.remove(merch);
		entitymanager.flush();


	}

	@Override
	public List<Merchant> loadAll() {
		System.out.println("in dao class method");
		String str = "SELECT merchant from Merchant merchant";
		TypedQuery<Merchant> query= entitymanager.createQuery(str,Merchant.class);
		
				return query.getResultList();
	}

	@Override
	public List<Merchant> getAllThirdPartyMerchants() {
		Query queryOne=entitymanager.createQuery("From Merchant where merchant_type = 'Third Party'"); //Employee is an entity, ie it is a class, not a table
		List<Merchant> myList=queryOne.getResultList();
		return myList;
	}

	@Override
	public List<Merchant> getThirdPartyMerId() {
		Query queryOne=entitymanager.createQuery("select merchantUId From Merchant where merchantType = 'Third Party'"); //Employee is an entity, ie it is a class, not a table
		List<Merchant> myList=queryOne.getResultList();
		return myList;
	}

	@Override
	public List<Product> allProductsOfThirdParty(String merId) {
		Query queryOne=entitymanager.createQuery("From Product where merchantId =:merId ");
		queryOne.setParameter("merId", merId);
		List<Product> myList=queryOne.getResultList();
		return myList;
	}
	

}
