package com.cg.capstore.dao;

import java.util.List;

import com.cg.capstore.dto.Merchant;
import com.cg.capstore.dto.Product;




public interface CapstoreDAO {

	public void save(Merchant merchant);
	public void delete(String merchantUId);
	public List<Merchant> loadAll();
	public List<Merchant> getAllThirdPartyMerchants();
	public List<Merchant> getThirdPartyMerId();
	public List<Product> allProductsOfThirdParty(String merId);
}
