package com.cg.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.dao.IPaymentWalletDao;
import com.cg.dao.PaymentWalletDaoImpl;
import com.cg.dto.Customer;
import com.cg.dto.Transactions;
import javax.transaction.Transaction;
import com.cg.exception.PaymentWalletException;


public class PaymentWalletServiceImpl implements IPaymentWalletService
{
	IPaymentWalletDao paymntdao  = new PaymentWalletDaoImpl();

	@Override
	public void createAccount(Customer customer)
	{
		// TODO Auto-generated method stub
		paymntdao.createAccount(customer);
		
	}

	@Override
	public void deposit(String custMobileNo, double amount) 
	{
		// TODO Auto-generated method stub
		 paymntdao.deposit(custMobileNo, amount);
		
	}

	@Override
	public void withdraw(String custMobileNo, double amount) {
		// TODO Auto-generated method stub
		 paymntdao.withdraw(custMobileNo, amount);
		
	}

	@Override
	public double checkBalance(String custMobileNo) {
		// TODO Auto-generated method stub
		return  paymntdao.checkBalance(custMobileNo);
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		// TODO Auto-generated method stub
		 paymntdao.fundTransfer(sender, reciever, amount);
		
	}

	@Override
	public boolean validateAccount(String custMobileNo) throws PaymentWalletException
	{
		return  paymntdao.validateAccount(custMobileNo);
		
	}

	@Override
	public boolean validateName(String custName) throws PaymentWalletException 
	{
		// TODO Auto-generated method stub
		if(custName == null)
			throw new PaymentWalletException("Null value found");
		Pattern p = Pattern.compile("[A-Z]{1}[a-z]{1,10}");
		Matcher m = p.matcher(custName); 
		if(!m.matches())
			System.out.println("Name invalid! Name should start with capital letter and should be of minimum 2 characters");
		return m.matches();
	}

	@Override
	public boolean validateAge(float custAge) throws PaymentWalletException {
		// TODO Auto-generated method stub
		try{
			if(custAge == 0)
				throw new PaymentWalletException("Age cannot be  null");
			else if(custAge < 0)
				throw new PaymentWalletException("Age cannot be a negative number");
			else if(custAge >100)
				throw new PaymentWalletException("Age cannot be  greater than 100");
			
			else if(custAge >17)
				return true;
			
		
	} catch (Exception e) {
		e.printStackTrace();
	}
		
		return false;
	}

	@Override
	public boolean validateMoileNo(String custMobileNo)
			throws PaymentWalletException {
		// TODO Auto-generated method stub
		try{
			if(custMobileNo == null)
				throw new PaymentWalletException("Null value found");
			Pattern p = Pattern.compile("[6789][0-9]{9}");
			Matcher m = p.matcher(custMobileNo);
			if(!m.matches())
				System.out.println("Mobile Number Invalid! Please enter valid Indian mobile number of 10 digits e.g 9867988985");
			return m.matches();
	} catch (Exception e) {
		e.printStackTrace();
	}
		return false;
		
	}

	@Override
	public boolean validateAmount(double amount) throws PaymentWalletException {
		// TODO Auto-generated method stub
		
		if(amount == 0)
			throw new PaymentWalletException("Null value found");
		String am = String.valueOf(amount);
		if(!am.matches("\\d{3,9}\\.\\d{0,4}"))
			System.out.println("Invalid Amount! Minimum transaction amount is 100 ");
		return (am.matches("\\d{3,9}\\.\\d{0,4}"));
		
	}

	@Override
	public List<Transactions> getTransList(String custmobileNo) {
		// TODO Auto-generated method stub
		return paymntdao.getTransList(custmobileNo);
	}

	
}
