package com.cg.service;

import java.util.List;

import com.cg.dto.Transactions;
import com.cg.dto.Customer;
import com.cg.exception.PaymentWalletException;


public interface IPaymentWalletService 
{
    public void createAccount(Customer customer);
	
	public void deposit(String custMobileNo, double amount);
	
	public void withdraw(String custMobileNo, double amount);
	
	public double checkBalance(String custMobileNo);
	
	public void fundTransfer(String sender, String reciever, double amount);
	
	
	public boolean validateAccount(String custMobileNo) throws PaymentWalletException;
	
	public boolean validateName(String custName) throws PaymentWalletException;
	
	public boolean validateAge(float custAge) throws PaymentWalletException;
	
	public boolean validateMoileNo(String custMobileNo) throws PaymentWalletException;
	
	public boolean validateAmount(double amount) throws PaymentWalletException;
	
	public List<Transactions> getTransList(String custmobileNo);

}
