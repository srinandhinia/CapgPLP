package com.cg.exception;

public class PaymentWalletException extends Exception{
	public PaymentWalletException(String message){
		super(message);
	}

}
