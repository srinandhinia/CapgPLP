package com.cg.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.dto.Customer;
import com.cg.dto.Transactions;
import com.cg.exception.PaymentWalletException;

public class PaymentWalletDaoImpl implements IPaymentWalletDao
{
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

	EntityManager manager;
	
	public PaymentWalletDaoImpl(){
		EntityManagerFactory emf= Persistence.createEntityManagerFactory("JPA-PU-Oracle");
		manager =emf.createEntityManager();
	}

	@Override
	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		manager.getTransaction().begin();
		manager.persist(customer);
		Transactions t5= new Transactions();
		t5.setCustMobileNo(customer.getCustMobileNo());
		t5.setTransamount(0);
		t5.setCre_deb("credit");
		t5.setBalance(customer.getInitialBalance());
		Date date = new Date();
		t5.setDate(String.valueOf(dateFormat.format(date)));
		manager.getTransaction().commit();
		System.out.println("Customer added\nName: "+customer.getCustName()+"\nMobile number: "+
		customer.getCustMobileNo()+"\nAge: "+customer.getCustAge()+"\nBalance: "+
				customer.getInitialBalance());

		
	}

	@Override
	public void deposit(String custMobileNo, double amount) {
		// TODO Auto-generated method stub
		manager.getTransaction().begin();
		Customer cust = manager.find(Customer.class, custMobileNo);
		double amt =cust.getInitialBalance();
		amt=amt+amount;
		cust.setInitialBalance(amt);
		manager.getTransaction().commit();
		passbookD(cust,amount);
		System.out.println("Amount deposited! New balance: "+amt);
		
	}

	@Override
	public void withdraw(String custMobileNo, double amount) {
		// TODO Auto-generated method stub
		manager.getTransaction().begin();
		Customer cust = manager.find(Customer.class, custMobileNo);
		double amt =cust.getInitialBalance();
		if(amt-amount>=100){
			amt=amt-amount;
			cust.setInitialBalance(amt);
			manager.getTransaction().commit();
			System.out.println("Amount withdrawn! New balance: "+amt);
		}
		else{
			System.out.println("Cannot withdraw! Minimum balance of Rs.100 should be maintained");
		}
		
	}

	@Override
	public double checkBalance(String custMobileNo) {
		// TODO Auto-generated method stub
		Customer cust = manager.find(Customer.class, custMobileNo);
		double amt =cust.getInitialBalance();
		System.out.println(amt);
		return amt;
		
		
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		manager.getTransaction().begin();
		Customer cust1 = manager.find(Customer.class, sender);
		double amt1 =cust1.getInitialBalance();
		Customer cust2 = manager.find(Customer.class, reciever);
		double amt2 =cust2.getInitialBalance();
		if(amt1-amount>=100){
			amt1=amt1-amount;
			amt2=amt2+amount;
			cust1.setInitialBalance(amt1);
			cust2.setInitialBalance(amt2);
			manager.getTransaction().commit();
			System.out.println("Amount transferred!\nNew balance in "+sender+" account is "+amt1);
		}
		else{
			System.out.println("Cannot tranfer! Sender has to maintain minimum balance of Rs.100");
		}
	}

	@Override
	public boolean validateAccount(String custMobileNo)
			throws PaymentWalletException {
		// TODO Auto-generated method stub
		Customer cust3=manager.find(Customer.class, custMobileNo);
		if(cust3==null)
			return false;
		return true;
	}

	@Override
	public void passbookD(Customer customer, double amount) {
		// TODO Auto-generated method stub
		Transactions t1= new Transactions();
		t1.setCustMobileNo(customer.getCustMobileNo());
		t1.setBalance(customer.getInitialBalance());
		t1.setTransamount(amount);
		Date date = new Date();
		t1.setDate(String.valueOf(dateFormat.format(date)));
		t1.setCre_deb("credit");
		manager.getTransaction().begin();
		manager.persist(t1);
		manager.getTransaction().commit();		
		
	}

	@Override
	public void passbookW(Customer customer, double amount) {
		// TODO Auto-generated method stub
		Transactions t2= new Transactions();
		t2.setCustMobileNo(customer.getCustMobileNo());
		t2.setBalance(customer.getInitialBalance());
		t2.setTransamount(amount);
		Date date = new Date();
		t2.setDate(String.valueOf(dateFormat.format(date)));
		t2.setCre_deb("debit");
		manager.getTransaction().begin();
		manager.persist(t2);
		manager.getTransaction().commit();	
		
	}

	@Override
	public void passbookF(Customer customer1, Customer customer2, double amount) {
		// TODO Auto-generated method stub
		manager.getTransaction().begin();
		Transactions t3= new Transactions();
		Transactions t4= new Transactions();
		t3.setCustMobileNo(customer1.getCustMobileNo());
		t3.setBalance(customer1.getInitialBalance());
		t3.setTransamount(amount);
		Date date = new Date();
		t3.setDate(String.valueOf(dateFormat.format(date)));
		t3.setCre_deb("debit");
		manager.persist(t3);
		t4.setCustMobileNo(customer2.getCustMobileNo());
		t4.setBalance(customer2.getInitialBalance());
		t4.setTransamount( amount);
		t4.setDate(String.valueOf(dateFormat.format(date)));
		t4.setCre_deb("credit");
		manager.persist(t4);		
		manager.getTransaction().commit();		
		
	}

	@Override
	public List<Transactions> getTransList(String mobileNo) {
		// TODO Auto-generated method stub
		String qr = "select trans from Transactions trans where mobileNo ="+mobileNo;
		TypedQuery<Transactions> query = manager.createQuery(qr, Transactions.class);
		List<Transactions> list = query.getResultList();
		return list;
		
	}


}
