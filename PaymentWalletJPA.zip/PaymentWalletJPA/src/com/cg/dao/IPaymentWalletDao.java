package com.cg.dao;

import java.util.List;

import com.cg.dto.Transactions;
import com.cg.dto.Customer;
import com.cg.exception.PaymentWalletException;

public interface IPaymentWalletDao 
{
    public void createAccount(Customer customer);
	
	public void deposit(String custMobileNo, double amount);
	
	public void withdraw(String custMobileNo, double amount);
	
	public double checkBalance(String custMobileNo);
	
	public void fundTransfer(String sender, String reciever, double amount);
	
	public boolean validateAccount(String custMobileNo) throws PaymentWalletException;
	

	public void passbookD(Customer customer, double amount);

	void passbookW(Customer customer, double amount);

	void passbookF(Customer customer1, Customer customer2, double amount);

	public List<Transactions> getTransList(String custMobileNo);
	
	
}
