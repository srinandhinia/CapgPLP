package com.cg.junit;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.cg.exception.PaymentWalletException;
import com.cg.service.IPaymentWalletService;
import com.cg.service.PaymentWalletServiceImpl;


public class TestCases 
{
	@Test(expected= PaymentWalletException.class)
    public void test_ValidateName_null() throws  PaymentWalletException{
        IPaymentWalletService paymntser=new PaymentWalletServiceImpl();
        paymntser.validateName(null);
    }
    
    @Test
    public void test_validateName_v1() throws  PaymentWalletException{
    
        String name="Nandhu246";
        IPaymentWalletService paymntser=new PaymentWalletServiceImpl();
        boolean result= paymntser.validateName(name);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateName_v2() throws  PaymentWalletException{
    
        String name="Nandhu";
        IPaymentWalletService paymntser=new PaymentWalletServiceImpl();
        boolean result= paymntser.validateName(name);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateName_v3() throws  PaymentWalletException{
    
        String name="nandhu";
        IPaymentWalletService paymntser=new PaymentWalletServiceImpl();
        boolean result= paymntser.validateName(name);
        Assert.assertEquals(false,result);
    }
    @Test(expected=PaymentWalletException.class)
    public void test_ValidateMobNo_null() throws  PaymentWalletException{
    	IPaymentWalletService paymntser=new PaymentWalletServiceImpl();
    	paymntser.validateMoileNo(null);
    }
    
    @Test
    public void test_validateMobNo_v1() throws  PaymentWalletException{
    
        String mobNo="ABCD949226";
        IPaymentWalletService paymntser=new PaymentWalletServiceImpl();
        boolean result= paymntser.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateMobNo_v2() throws  PaymentWalletException{
    
        String mobNo="9492269519";
        IPaymentWalletService paymntser=new PaymentWalletServiceImpl();
        boolean result= paymntser.validateMoileNo(mobNo);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateMobNo_v3() throws  PaymentWalletException{
    
        String mobNo="949226";
        IPaymentWalletService paymntser=new PaymentWalletServiceImpl();
        boolean result= paymntser.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }
	
	

}
