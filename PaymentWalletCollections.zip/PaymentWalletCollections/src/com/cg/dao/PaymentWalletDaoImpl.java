package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.dto.Customer;
import com.cg.exception.PaymentWalletException;

public class PaymentWalletDaoImpl implements IPaymentWalletDao
{

	Map<String,Customer> custMap;
	
	public PaymentWalletDaoImpl(){
	custMap = new HashMap<>();
	custMap.put("8790132898", new Customer("8790132898", "Nandhini", 22, 5000));
	custMap.put("8008560302", new Customer("8008560302", "Srilekha", 36, 6000));
	custMap.put("9676811120", new Customer("9676811120", "Priyanka", 63, 10000));
	}

	@Override
	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		custMap.put(customer.getCustMobileNo(),customer);
		
	}

	@Override
	public void deposit(String custMobileNo, double amount) {
		// TODO Auto-generated method stub
		Customer customer = custMap.get( custMobileNo);
		if(customer != null){
			double updateAmount = customer.getInitialBalance();
			updateAmount += amount;
			String name = customer.getCustName();
			String newMobileNo = customer.getCustMobileNo();
			float age = customer.getCustAge();
			
			customer.setCustAge(age);;
			customer.setInitialBalance(updateAmount);
			customer.setCustName(name);;
			customer.setCustMobileNo(newMobileNo);;
			
			custMap.put(newMobileNo, customer);
			System.out.println("Amount deposited! New balance: "+ customer.getInitialBalance());
		}
		
	}

	@Override
	public void withdraw(String custMobileNo, double amount) {
		// TODO Auto-generated method stub
		Customer customer = custMap.get(custMobileNo);
		if(customer != null){
			double actamount = customer.getInitialBalance();	
			
			String name = customer.getCustName();
			String newMobileNo = customer.getCustMobileNo();
			float age = customer.getCustAge();
			
			if(actamount - amount > 500){
				actamount -= amount;
				customer.setCustAge(age);;
				customer.setInitialBalance(actamount);
				customer.setCustName(name);;
				customer.setCustMobileNo(newMobileNo);;
				
				custMap.put(newMobileNo, customer);
				System.out.println("Amount withdrawn! New balance: "+ customer.getInitialBalance());
			}
			else{
				System.out.println("Cannot withdraw! Minimum balance of 100 should be maintained");
			}
			}
		else{
			System.out.println("Mobile number not found");
		}
		
	}

	@Override
	public double checkBalance(String custMobileNo) {
		// TODO Auto-generated method stub
		Customer custCheckBalance = custMap.get(custMobileNo);
		double amount = custCheckBalance.getInitialBalance();
		return amount;
		
		
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		// TODO Auto-generated method stub
		String name, newMobileNo;
		float age;
		
		Customer custSender =  custMap.get(sender);
		Customer custReciever = custMap.get(reciever);
		
		double recieverAmount = custReciever.getInitialBalance();
		double senderAmount = custSender.getInitialBalance();
		if(senderAmount - amount > 500){
			recieverAmount += amount;
			senderAmount -= amount;
			name = custSender.getCustName();
			newMobileNo = custSender.getCustMobileNo();
			age = custSender.getCustAge();
		
			
			custSender.setCustAge(age);;
			custSender.setInitialBalance(senderAmount);
			custSender.setCustMobileNo(newMobileNo);;
			custSender.setCustName(name);;
			
			custMap.put(newMobileNo, custSender);
			
			name = custReciever.getCustName();
			newMobileNo = custReciever.getCustMobileNo();
			age = custReciever.getCustAge();
			
			
			custReciever.setCustAge(age);;
			custReciever.setInitialBalance(recieverAmount);
			custReciever.setCustMobileNo(newMobileNo);;
			custReciever.setCustName(name);;
			
			custMap.put(newMobileNo, custReciever);	
			System.out.println("Fund Transferred! new balance :"+senderAmount);
		}
		else{
			System.out.println("Cannot transfer! Minimum balance of 100 should be maintained in Sender's account");
		}
		
		
	}

	@Override
	public boolean validateAccount(String custMobileNo)
			throws PaymentWalletException {
		// TODO Auto-generated method stub
		Customer customer = custMap.get(custMobileNo);
		if(customer == null)
			return false;
		return true;
		
	}


}
