package com.cg.dto;

public class Customer 
{
	private String custName;
	private String custMobileNo;
	private float custAge;
	private double initialBalance;

	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustMobileNo() {
		return custMobileNo;
	}
	public void setCustMobileNo(String custMobileNo) {
		this.custMobileNo = custMobileNo;
	}
	public float getCustAge() {
		return custAge;
	}
	public void setCustAge(float custAge) {
		this.custAge = custAge;
	}
	public double getInitialBalance() {
		return initialBalance;
	}
	public void setInitialBalance(double initialBalance) {
		this.initialBalance = initialBalance;
	}
	
	public Customer(String custName, String custMobileNo, float custAge,
			double initialBalance) {
		super();
		this.custName = custName;
		this.custMobileNo = custMobileNo;
		this.custAge = custAge;
		this.initialBalance = initialBalance;
	}
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
