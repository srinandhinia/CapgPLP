package com.cg.ui;

import java.util.Scanner;

import com.cg.dto.Customer;
import com.cg.exception.PaymentWalletException;
import com.cg.service.IPaymentWalletService;
import com.cg.service.PaymentWalletServiceImpl;


public class Main {
	public static void main(String args[]) throws PaymentWalletException{
		
		IPaymentWalletService paymntser = new PaymentWalletServiceImpl();
		
		Scanner sc = new Scanner(System.in);
		
		String custName,custMobileNo;
		float custAge;
		double amount;
		int ch = 0;
		do{
			System.out.println("1.Add Customer\n2.Deposit amount\n3.Withdraw Amount\n4.Fund transfer\n5.Check balance\n6.Exit");
			System.out.println("Enter your choice : ");
			ch = sc.nextInt();
			Customer customer;
			switch(ch){
				case 1 :					
						do{
							do{
							System.out.println("Enter customer name : ");
							custName = sc.next();
							if(paymntser.validateName(custName))
								break;
							}while(true);
							
							do{
							System.out.println("Enter mobile no. : ");
							custMobileNo = sc.next();
							if(paymntser.validateMoileNo(custMobileNo))
								break;
							}while(true);
							
							do{
							System.out.println("Enter age : ");
							custAge = sc.nextFloat();
							if(paymntser.validateAge(custAge))
								break;
							}while(true);
							
							do{
							System.out.println("Enter initial amount : ");
							amount = sc.nextDouble();
							if(paymntser.validateAmount(amount))
								break;
							}while(true);
							
							if(!paymntser.validateAccount(custMobileNo))
								break;
							else
								System.out.println("Account already exists!");
							
						}while(true);
						
						customer = new Customer();
						customer.setCustName(custName);
						customer.setCustMobileNo(custMobileNo);;
						customer.setCustAge(custAge);
						customer.setInitialBalance(amount);
						paymntser.createAccount(customer);		
						System.out.println("Customer added!");
					break;
					
				case 2 :
						do{
							do{
								System.out.println("Enter your mobile no. : ");
								custMobileNo = sc.next();
								if(paymntser.validateMoileNo(custMobileNo))
									break;
								}while(true);
							
							do{
								System.out.println("Enter amount you want to deposit: ");
								amount = sc.nextDouble();
								if(paymntser.validateAmount(amount))
									break;
								}while(true);

							if(!paymntser.validateAccount(custMobileNo))
								System.out.println("Account not found! Check mobile number");
							else
								break;
						}while(true);
						
						paymntser.deposit(custMobileNo, amount);		
					
					break;
					
				case 3 :
					do{
						do{
							System.out.println("Enter your mobile no. : ");
							custMobileNo = sc.next();
							if(paymntser.validateMoileNo(custMobileNo))
								break;
							}while(true);
						
						do{
							System.out.println("Enter amount you want to withdraw: ");
							amount = sc.nextDouble();
							if(paymntser.validateAmount(amount))
								break;
							}while(true);

						if(!paymntser.validateAccount(custMobileNo))
							System.out.println("Account not found! Check mobile number");
						else
							break;
					}while(true);
					
					customer = new Customer();
					paymntser.withdraw(custMobileNo, amount);
						
					break;
				
				case 4 :
						String mobileNoReciever;
						do{
							do{
							System.out.println("Enter your mobile number : ");
							custMobileNo = sc.next();
							if(paymntser.validateMoileNo(custMobileNo)){
								if(paymntser.validateAccount(custMobileNo))
									break;
								else
									System.out.println("Account doesnt exists!");
							}
							}while(true);
							
							do{
							System.out.println("Enter the amount you want to transfer : ");
							amount = sc.nextDouble();
							if(paymntser.validateAmount(amount))
								break;
							}while(true);
							
							do{
							System.out.println("Enter receivers mobile number : ");
							mobileNoReciever = sc.next();
							if(paymntser.validateMoileNo(mobileNoReciever)){
								if(paymntser.validateAccount(mobileNoReciever))
									break;
								else
									System.out.println("Account doesnt exists!");
							}
							}while(true);
							
							if(!custMobileNo.equals(mobileNoReciever))
								break;
							else
								System.out.println("Sender and receiver mobile number cannot be same.");
							}while(true);							
						paymntser.fundTransfer(custMobileNo, mobileNoReciever, amount);
						break;
					
				case 5 :
						do{
							System.out.println("Enter the moible id to check balance");
							custMobileNo = sc.next();
							if(paymntser.validateMoileNo(custMobileNo)){
								if(paymntser.validateAccount(custMobileNo))
									break;
								else
									System.out.println("Account doesnt exists!");
							}
						}while(true);
						
						System.out.println("Current Amount "+paymntser.checkBalance(custMobileNo));
						
					break;
					
				case 6 :
						System.out.println("Application terminated");
					break;
				default : System.out.println("Invalid input!");
			}
			
		}while(ch != 6);
		sc.close();
		
	}
}
